//#include "eeconfig.h"


enum combos {
  //QW_BS,
  //YI_Ent,//not great for hebrew ון, swap with ER, CV, MComma
  FG_Ent,
  DF_BS,
  JK_BS,
  HJ_Ent,
  CV_Ent,
  MPsik_Ent,
  YINUMPAD_Ent,
};

//const uint16_t PROGMEM qw_combo[] = {KC_Q, KC_W, COMBO_END};
//const uint16_t PROGMEM yi_combo[] = {KC_Y,	KC_I, COMBO_END};
const uint16_t PROGMEM fg_combo[] = {ARROWS_F,GUI_G, COMBO_END};
const uint16_t PROGMEM df_combo[] = {ALT_D,	ARROWS_F, COMBO_END};
const uint16_t PROGMEM jk_combo[] = {GUI_J,	ALT_K, COMBO_END};
const uint16_t PROGMEM hj_combo[] = {KC_H,GUI_J, COMBO_END};
const uint16_t PROGMEM yiNumpad_combo[] = {KC_EQUAL,KC_8, COMBO_END};
const uint16_t PROGMEM cv_combo[] = {KC_C, KC_V, COMBO_END};
const uint16_t PROGMEM mpsik_combo[] = {KC_M,	KC_COMM, COMBO_END};

combo_t key_combos[COMBO_COUNT] = {
  //[QW_BS] = COMBO(qw_combo, KC_ENT),
  //[YI_Ent] = COMBO(yi_combo, KC_BSPC),
  [FG_Ent] = COMBO(fg_combo, KC_ENT),
  [DF_BS] = COMBO(df_combo, KC_BSPC),
  [JK_BS] = COMBO(jk_combo, KC_BSPC),
  [HJ_Ent] = COMBO(hj_combo, KC_ENT),
  [CV_Ent] = COMBO(cv_combo, KC_ENT),
  [MPsik_Ent] = COMBO(mpsik_combo, KC_ENT),
  [YINUMPAD_Ent] = COMBO(yiNumpad_combo, KC_BSPC)

};

